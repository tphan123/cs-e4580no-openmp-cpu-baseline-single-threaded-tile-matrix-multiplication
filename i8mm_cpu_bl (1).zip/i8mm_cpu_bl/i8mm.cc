#include "mm.h"

/*
This is the function you need to implement. Quick reference:
 matrix A: (m, k); A[i, j] = A[i*k + j]
 matrix B: (k, n); B[i, j] = B[i+n + j]
 matrix C: (m, n); C[i, j] = C[i*n + j]
*/
void gemm(int m, int n, int k, const std::int8_t *A, const std::int8_t *B, std::int32_t *C) {
}
