#!/usr/bin/env python3

import sys

if sys.version_info < (3, 9):
    sys.exit('Expected Python version 3.9 or later.')

BOX_PATH = '/box/'
